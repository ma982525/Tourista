<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'id16385515_admin');
   define('DB_PASSWORD', 'ManishParmar@123');
   define('DB_DATABASE', 'id16385515_tourista');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>